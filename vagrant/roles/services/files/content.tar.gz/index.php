 <?php 
 Print "Hello, World!";
 echo time();
 ?> 
