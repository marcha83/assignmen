 <?php
 Print "test.php!";
 echo time();
 ?>
