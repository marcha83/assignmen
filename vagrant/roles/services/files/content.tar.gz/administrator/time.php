 <?php

 echo time();

 ?>
